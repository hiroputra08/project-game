/** Automatically generated file. DO NOT MODIFY */
package com.example.multi_page;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}