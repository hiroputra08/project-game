package com.example.multi_page;

import android.R.string;

public class Data_profileku {
	//data profile
	public static String nama ="Moch Tocha";
	public static int jml_aplikasi =10;
	public static int jml_followers =100;
	public static int jml_following =50;
	public static String keterangan = "NAMA TOCHA SLEBEW BOSSSSSS";

	//login pengguna
public static String username="budi";
public static String password="12345";


}

