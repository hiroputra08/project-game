package com.example.multi_page;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditActivity extends Activity {

	EditText editnama, editjmlapp, editjmlfoll,
	editjmlwing, editket;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit);
		
		editnama= (EditText) findViewById(R.id.inputnama);
		editjmlapp= (EditText) findViewById(R.id.inputaplikasi);
		editjmlfoll= (EditText) findViewById(R.id.inputfoll);
		editjmlwing= (EditText) findViewById(R.id.inputwing);
		editket= (EditText) findViewById(R.id.inputket);
		
		editnama.setText(Data_profileku.nama);
		editjmlapp.setText(String.valueOf(Data_profileku.jml_aplikasi));
		editjmlfoll.setText(String.valueOf(Data_profileku.jml_followers));
		editjmlwing.setText(String.valueOf(Data_profileku.jml_following));
		editket.setText(String.valueOf(Data_profileku.keterangan));
		
		
		
		Button btnbback=(Button) findViewById(R.id.btnbbackkk);
		btnbback.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		Button btnsave=(Button) findViewById(R.id.btnsave);
		btnsave.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Data_profileku.nama = editnama.getText().toString();
				Data_profileku.jml_aplikasi= Integer.parseInt(editjmlapp.getText().toString());
				Data_profileku.jml_followers= Integer.parseInt(editjmlfoll.getText().toString());
				Data_profileku.jml_following= Integer.parseInt(editjmlwing.getText().toString());
				Data_profileku.keterangan = editket.getText().toString();
				Toast.makeText(getApplicationContext(), "Data Berhasil Disimpan",
				Toast.LENGTH_SHORT).show();
				finish();
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.edit, menu);
		return true;
	}

}
