package com.example.multi_page;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class Profile extends Activity {

	void tampilkanData() {
		// mengisi textview pada profile ============================
		TextView lblnama = (TextView) findViewById(R.id.namaku);
		lblnama.setText(Data_profileku.nama);

		TextView lbljmlapp = (TextView) findViewById(R.id.jmlapp);
		lbljmlapp.setText(String.valueOf(Data_profileku.jml_aplikasi));

		TextView lbljmlfoll = (TextView) findViewById(R.id.jmlfoll);
		lbljmlfoll.setText(String.valueOf(Data_profileku.jml_followers));

		TextView lbljmlwing = (TextView) findViewById(R.id.jmlwing);
		lbljmlwing.setText(String.valueOf(Data_profileku.jml_following));

		TextView about = (TextView) findViewById(R.id.about);
		about.setText("About" + Data_profileku.nama);

		TextView lblket = (TextView) findViewById(R.id.keterangan);
		lblket.setText(Data_profileku.keterangan);
		// ============================================================

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
tampilkanData();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);

		tampilkanData();
		
		Button btnbback = (Button) findViewById(R.id.btnbback);
		btnbback.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(getApplicationContext(), Utama.class);
				startActivity(i);

			}
		});

		Button btnlogout = (Button) findViewById(R.id.btnlogout);
		btnlogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				finish();
				Intent i = new Intent(getApplicationContext(), Login.class);
				startActivity(i);
			}
		});

		ImageView btnedi = (ImageView) findViewById(R.id.btnedi);
		btnedi.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent i = new Intent(getApplicationContext(),
						EditActivity.class);
				startActivity(i);
				// TODO Auto-generated method stub

			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.profile, menu);
		return true;
	}

}
